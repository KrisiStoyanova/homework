package Homework10.Helpers;

import PageObjectModels.DropdownsPage;
import PageObjectModels.SignUpPage;
import PageObjectModels.TestPage;
import PageObjectModels.WebElements;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

public class TestCases extends BaseTest {

    WebElements objWebElements;
    DropdownsPage objDropdownPage;
    SignUpPage objSignUpPage;
    TestPage objTestPage;


    @BeforeClass
    public static void setup(){
        BaseTest.initialize();
    }

    @Test

    public void goBackToPreviousPage() {

        // Create Dropdowns page object
        objDropdownPage = new DropdownsPage(driver);

        //Method that performs click action
        //webElements.ClickAction();
        objDropdownPage.clickAction();

        //Method to verify /sign up page URL
        objSignUpPage.verifySignUpPage();

        //Go back to Dropdowns page via browser
        driver.navigate().back();

        //Method to verify /dropdowns page URL
        objDropdownPage.verifyDropdownsPage();

        System.out.println("Test Case 1: passed");
    }

    @AfterClass
    public static void teardown(){
        BaseTest.quit();
    }

    /*public static WebDriver driver;

    WebElements objWebElements;
    DropdownsPage objDropdownPage;
    SignUpPage objSignUpPage;
    TestPage objTestPage;

    @Test

    public void goBackToPreviousPage() {

        // Create Dropdowns page object
        objDropdownPage = new DropdownsPage(driver);

        //Method that performs click action
        //webElements.ClickAction();
        objDropdownPage.clickAction();

        //Method to verify /sign up page URL
        objSignUpPage.verifySignUpPage();

        //Go back to Dropdowns page via browser
        driver.navigate().back();

        //Method to verify /dropdowns page URL
        objDropdownPage.verifyDropdownsPage();

        System.out.println("Test Case 1: passed");
    }*/
}
