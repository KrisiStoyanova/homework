package Homework10.Helpers;

public class Constants {

    public static String browserName = "Chrome";
    public static String url = "https://letcode.in/dropdowns";
}
