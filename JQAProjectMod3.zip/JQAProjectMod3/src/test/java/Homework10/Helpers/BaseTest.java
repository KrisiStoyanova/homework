package Homework10.Helpers;

import Helpers.BrowserFactory;
import PageObjectModels.DropdownsPage;
import PageObjectModels.SignUpPage;
import PageObjectModels.TestPage;
import PageObjectModels.WebElements;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class BaseTest {

    public static WebDriver driver;

    public static void initialize(){

    if(driver == null){
        if(Constants.browserName.equalsIgnoreCase("Chrome")) {
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\IdeaProjects\\JQAProjectMod3\\src\\test\\resources\\drivers\\chromedriver.exe");
            driver = new ChromeDriver();
        }
        else if(Constants.browserName.equalsIgnoreCase("Edge")){
             System.setProperty("webdriver.edge.driver", "C:\\Users\\user\\IdeaProjects\\JQAProjectMod3\\src\\test\\resources\\drivers\\msedgedriver.exe");
             driver = new EdgeDriver();
            }
        }
    driver.manage().window().maximize();
    driver.get(Constants.url);
    }

    /*WebElements objWebElements;
    DropdownsPage objDropdownPage;
    SignUpPage objSignUpPage;
    TestPage objTestPage;

    @BeforeClass
    public static void setup() {
        //System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\IdeaProjects\\JQAProjectMod3\\src\\test\\resources\\drivers\\chromedriver.exe");
        //driver = new ChromeDriver();
        driver.get("https://letcode.in/dropdowns");
        driver.manage().window().maximize();
    }

    @AfterClass*/

    public static void quit() {
        driver.quit();
        driver = null;
    }
}
