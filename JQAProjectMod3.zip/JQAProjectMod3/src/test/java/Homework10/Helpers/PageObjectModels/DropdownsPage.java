package Homework10.Helpers.PageObjectModels;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownsPage extends WebElements {

    WebDriver driver;

    public DropdownsPage(WebDriver driver) {
        super(driver);
    }

    //public DropdownsPage(WebDriver driver) {
        //this.driver = driver;
    //}

    //public DropdownsPage() {
        //driver = null;
    //}


    //public DropdownsPage(WebDriver driver) {
        //super(driver);
    //}

    //WebDriver driver;

    //public DropdownsPage(WebDriver driver) {
    //this.driver = driver;
    //}

    //Method that performs click action
    public void clickAction() {
        driver.findElement(signUpButton).click();
    }

    //Method to verify /dropdowns page URL
    public void verifyDropdownsPage() {
        String actualUrlDropdownsPage = driver.getCurrentUrl();
        System.out.println("Going back to previous page/Dropdowns page URL: " + actualUrlDropdownsPage);
        String expectedUrlDropdownsPage = "https://letcode.in/dropdowns";
        Assert.assertEquals(expectedUrlDropdownsPage, actualUrlDropdownsPage);
    }

    //Method to select value in dropdown
    //public void clickDropdown(){
        //dropdown.findElement(By.cssSelector("#lang > option:nth-child(2)")).sendKeys(Keys.chord(Keys.ALT, Keys.TAB));
    //}

    public void selectDropdown (String JavaScript) {
        //Select dropdown = new Select(driver.findElement(By.id("lang")));
        //dropdown.selectByVisibleText(JavaScript); // "Currency Derivatives"
    }
    public void selectValue(String symbol) {
        driver.findElement(dropdown).sendKeys("Java");
    }


    //Method to verify success notification
    public void verifySuccessNotification() {
        String actualSuccessNotification = driver.findElement(By.cssSelector("p.subtitle")).getAttribute("innerHTML");
        System.out.println(actualSuccessNotification);
        String expectedSuccessNotification = "You have selected Java";
        Assert.assertEquals(expectedSuccessNotification, actualSuccessNotification);
    }

    //Method that opens a new tab
    public void OpenLink() {
        driver.findElement(link).sendKeys(Keys.chord(Keys.CONTROL, Keys.ENTER));
    }


    //public void clickDropdown() {
        //dropdown.findElement(By.cssSelector("#lang > option:nth-child(2)")).sendKeys(Keys.chord(Keys.ALT, Keys.TAB));
    //}


}




