package ProjectMod3.POM;

import ProjectMod3.POM.Helpers.BrowserFactory;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

public class Runner {

    @RunWith(Cucumber.class)
    @CucumberOptions(strict = true,
            features = {"src/test/resources/features:features/"},
            tags = {"@desktop @mobile @tablet"},
            plugin = {"pretty", "html:target/cucumber-reports"},
            monochrome = true
    )
    public class RunCucumberTest extends BrowserFactory {

    }

}
