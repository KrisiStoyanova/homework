package ProjectMod3.POM;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import java.util.concurrent.TimeUnit;

public class StepDefinition {

    WebDriver driver;

    @Given("user navigates to store page on desktop.")
    public void user_navigates_to_store_page_on_desktop() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\IdeaProjects\\JQAProjectMod3\\src\\test\\resources\\drivers\\chromedriver.exe");
        driver = new ChromeDriver();

        //Dimension dimension = new Dimension(930, 410);

        Dimension desktopViewport = new Dimension(1366, 768);
        driver.manage().window().setSize(desktopViewport);

        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        driver.get("https://demoqa.com/books");
    }

    @Given("user navigates to store page on mobile.")
    public void user_navigates_to_store_page_on_mobile() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\IdeaProjects\\JQAProjectMod3\\src\\test\\resources\\drivers\\chromedriver.exe");
        driver = new ChromeDriver();

        //Dimension dimension = new Dimension(930, 410);

        Dimension mobileViewport = new Dimension( 360, 640);
        driver.manage().window().setSize(mobileViewport);

        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        driver.get("https://demoqa.com/books");
    }

    @Given("user navigates to store page on tablet.")
    public void user_navigates_to_store_page_on_tablet() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\IdeaProjects\\JQAProjectMod3\\src\\test\\resources\\drivers\\chromedriver.exe");
        driver = new ChromeDriver();

        //Dimension dimension = new Dimension(930, 410);

        Dimension tabletViewport = new Dimension(768, 1024);
        driver.manage().window().setSize(tabletViewport);

        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        driver.get("https://demoqa.com/books");
    }

    @When("user click on any product link.")
    public void userClickOnAnyProductLink() {
        StorePage storePage = PageFactory.initElements(driver, StorePage.class);
        storePage.clickTabLink();
    }

    @Then("user should be navigated to product detailed page.")
    public void userShouldBeNavigatedToProductDetailedPage() {
        ProductPage productPage = PageFactory.initElements(driver, ProductPage.class);
        productPage.explicitWaitProductPage();
        productPage.verifyProductPage();
    }

    @Then("back button is displayed.")
    public void back_button_is_displayed() {
        ProductPage productPage = PageFactory.initElements(driver, ProductPage.class);
        productPage.explicitWaitBackButton();
        driver.findElement(By.xpath("//*[@id=\"addNewRecordButton\"]")).isDisplayed();
    }

    @When("user click the back button.")
    public void userClickTheBackButton() {
        ProductPage productPage = PageFactory.initElements(driver, ProductPage.class);
        productPage.clickBackButton();
    }

    @Then("user should be navigated back to store page.")
    public void userShouldBeNavigatedBackToStorePage() {
        StorePage storePage = PageFactory.initElements(driver, StorePage.class);
        storePage.explicitWaitStorePage();
        storePage.verifyStorePage();
    }
}
