package ProjectMod3.POM;

import Homework11.ExpectedConditions;
import PageObjectModels.DropdownsPage;
import PageObjectModels.SignUpPage;
import PageObjectModels.TestPage;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class TestScenario {

    /*public static WebDriver driver;

    @BeforeClass
    public static void openBrowser() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\IdeaProjects\\JQAProjectMod3\\src\\test\\resources\\drivers\\chromedriver.exe");
        driver = new ChromeDriver();

        Dimension dimension = new Dimension(930, 410);
        driver.manage().window().setSize(dimension);

        //driver.manage().window().maximize();
        //System.out.println("Implicit wait for Dropdowns page.");
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        driver.get("https://demoqa.com/books");
    }

    //Scenario - User shall be able to go back to store page via back button on product page
    @Test
    public void goBackToStorePage() {

        StorePage storePage = PageFactory.initElements(driver, StorePage.class);
        ProductPage productPage = PageFactory.initElements(driver, ProductPage.class);

        //Method to perform click action
        storePage.clickAction();

        //Method to explicitly wait sign up page assertion
        //explicitWaitSignUpPage();

        //Method to verify product page URL
        productPage.verifyProductPage();

        //Click back button
        productPage.clickBackButton();

        //Method to explicitly wait dropdowns page assertion
        //explicitWaitDropdownsPage();

        //Method to verify store page URL
        storePage.verifyStorePage();

        System.out.println("Test Case 1: passed");

    }

*/
}
