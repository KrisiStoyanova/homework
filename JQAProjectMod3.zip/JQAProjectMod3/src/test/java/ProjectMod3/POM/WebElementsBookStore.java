package ProjectMod3.POM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
/*
public class WebElementsBookStore {

    //@FindBy(xpath = "//*[@id=\"see-book-Git Pocket Guide\"]/a")
    //WebElement productLink;

    //Locating 1st link for a product
    //@FindBy(linkText = "Git Pocket Guide")
    //WebElement productLink;

    //Locating Back button
    //@FindBy(xpath = "//*[@id=\"addNewRecordButton\"]")
    //WebElement backButton;

}*/




