package PageObjectModels;

import Helpers.BrowserFactory;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class SignUpPage extends WebElements {

    WebDriver driver;

    public SignUpPage(WebDriver driver) {
        this.driver = driver;
    }
    //public SignUpPage(WebDriver driver) {
    //super(driver);
    //}

    //WebDriver driver = null;

    //public SignUpPage(WebDriver driver) {
    //this.driver = driver;
    //}

    //Method to verify /sign up page URL
    public void verifySignUpPage() {
        String actualUrlSignUpPage = driver.getCurrentUrl();
        System.out.println("Redirection to page/Sign up page URL: " + actualUrlSignUpPage);
        String expectedUrlSignUpPage = "https://letcode.in/signup";
        Assert.assertEquals(expectedUrlSignUpPage, actualUrlSignUpPage);
    }
}





