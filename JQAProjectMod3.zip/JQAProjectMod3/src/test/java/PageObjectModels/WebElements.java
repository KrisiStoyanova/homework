package PageObjectModels;

import Helpers.Before;
import Helpers.BrowserFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class WebElements {

    //inal WebDriver driver;

    //public WebElements(WebDriver driver){
        //this.driver=driver;
    //}

    //WebDriver driver = null;

    //public WebElements(WebDriver driver) {
        //this.driver = driver;
    //}

    //Locating 'Sign up' button
    @FindBy(linkText = "Sign up")
    WebElement signUpButton;

    //Locating 'Work-Space' link
    @FindBy(xpath = "//*[@id='testing']")
    WebElement link;

    //Locating dropdown
    @FindBy(id = "lang")
    WebElement dropdown;


    }


    //public WebElements() {
        //driver = null;
    //}

    //Method that performs click action
    //public void clickAction() {
        //signUpButton.click();
    //}

    //Method that opens a new tab
    //public void OpenLink() {
        //link.sendKeys(Keys.chord(Keys.CONTROL, Keys.ENTER));


    //Locating programming language dropdown
    //Select dropdown = new Select(driver.findElement(By.id("lang")));

    //Method that selects a value
    //public void SelectValue() {
        //dropdown.selectByValue("java");



