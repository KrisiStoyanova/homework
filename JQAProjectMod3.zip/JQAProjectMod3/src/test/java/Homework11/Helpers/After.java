package Homework11.Helpers;

public class After extends BrowserFactory {
    public void quit () {
        closeBrowser();
    }
}
