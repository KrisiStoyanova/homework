package Homework11.Helpers;

import Helpers.BrowserFactory;

public class After extends BrowserFactory {
    public void quit () {
        closeBrowser();
    }
}


