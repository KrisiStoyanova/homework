package Homework11.Helpers;

import org.openqa.selenium.WebDriver;

public class Before extends BrowserFactory {
/*
    public static void setup() {
        //Create a Chrome driver. All test classes use this.
        WebDriver driver = BrowserFactory.getBrowser("Chrome");
        driver.get("https://letcode.in/dropdowns");
        driver.manage().window().maximize();
        //WebElements webElements = PageFactory.initElements(driver, WebElements.class);
        //DropdownsPage dropdownsPage = PageFactory.initElements(driver, DropdownsPage.class);
    }
*/
}
