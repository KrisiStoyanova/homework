package TestCases;

import Helpers.After;
import Helpers.Before;
import Helpers.BrowserFactory;
import PageObjectModels.DropdownsPage;
import PageObjectModels.SignUpPage;
import PageObjectModels.WebElements;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class SelectValueFromDropdown {

    static WebDriver driver;

    //@BeforeClass
    //public static void openBrowser(){
        //Before.setup();
    //}

    @Test
    public void selectValueFromDropdown() {

        Before.setup();

        WebDriver driver = BrowserFactory.getBrowser("Chrome");
        driver.get("https://letcode.in/dropdowns");
        driver.manage().window().maximize();
        //Test case 3 - User shall be able to select a value from programming language dropdown

        //WebElements webElements = PageFactory.initElements(driver, WebElements.class);
        //DropdownsPage dropdownsPage = PageFactory.initElements(driver, DropdownsPage.class);

        WebElements webElements = PageFactory.initElements(driver, WebElements.class);
        DropdownsPage dropdownsPage = PageFactory.initElements(driver, DropdownsPage.class);

        //Select "java" from programming language dropdown
        dropdownsPage.selectDropdown("JavaScript");
        dropdownsPage.selectValue("Java");

        //Select dropdown = new Select(driver.findElement(By.id("lang")));
        //dropdown.selectByValue("java");
        //Verify success notification
        dropdownsPage.verifySuccessNotification();
        //Assert.assertTrue("Success notification match", expectedSuccessNotification.equals(actualSuccessNotification));
        System.out.println("Test Case 3: passed");
    }



    @AfterClass
    public static void closeBrowser() {
        BrowserFactory.closeBrowser();

    }




}
