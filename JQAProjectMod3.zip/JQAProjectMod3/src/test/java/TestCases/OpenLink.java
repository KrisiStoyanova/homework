package TestCases;

import Helpers.After;
import Helpers.BrowserFactory;
import PageObjectModels.DropdownsPage;
import PageObjectModels.SignUpPage;
import PageObjectModels.TestPage;
import PageObjectModels.WebElements;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;

public class OpenLink {

    static WebDriver driver;


    @Test
    public void openLink() {

        WebDriver driver = BrowserFactory.getBrowser("Chrome");
        driver.get("https://letcode.in/dropdowns");
        driver.manage().window().maximize();

        //Test case 2 - User shall be able to open 'Work-Space' link in new tab

        WebElements webElements = PageFactory.initElements(driver, WebElements.class);
        TestPage signUpPage = PageFactory.initElements(driver, TestPage.class);
        DropdownsPage dropdownsPage = PageFactory.initElements(driver, DropdownsPage.class);

        //Method that opens link in new tab
        dropdownsPage.OpenLink();

        ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
        //switch to new tab
        driver.switchTo().window(newTab.get(1));

        //Method to verify /test page URL
        signUpPage.verifyTestPage();

        //Switch to parent tab
        driver.switchTo().window(newTab.get(0));

    }

    @AfterClass
    public static void closeBrowser() {
        After.closeBrowser();

    }
}
