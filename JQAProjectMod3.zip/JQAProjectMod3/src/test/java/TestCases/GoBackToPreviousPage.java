package TestCases;

import Helpers.After;
import Helpers.Before;
import Helpers.BrowserFactory;
import PageObjectModels.DropdownsPage;
import PageObjectModels.SignUpPage;
import PageObjectModels.WebElements;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class GoBackToPreviousPage<driver1> {

    static WebDriver driver;

    //WebElements objWebElements;
    //DropdownsPage objDropdownsPage;
    //SignUpPage objSignUpPage;
    //TestPage objTestPage;

    //@BeforeClass
    //public static void setup() {
        //WebDriver driver = BrowserFactory.getBrowser("Chrome");
        //driver.get("https://letcode.in/dropdowns");
        //driver.manage().window().maximize();
    //}

    //}

    @Test
    public void goBackToPreviousPage() {
        WebDriver driver = BrowserFactory.getBrowser("Chrome");
        driver.get("https://letcode.in/dropdowns");
        driver.manage().window().maximize();


        //Test that both the browsers are actually only one instance of chrome driver
        //WebDriver driver1 = BrowserFactory.getBrowser("Chrome");
        //if (driver.equals(driver1)) {
            //System.out.println("The two chrome drivers are same");
        //}

            //objWebElements = new WebElements(driver);
            //objDropdownsPage = new DropdownsPage(driver);
            //objSignUpPage = new SignUpPage(driver);

            // Test case 1 - User shall be able to go back to previous page (via browser)

            WebElements webElements = PageFactory.initElements(driver, WebElements.class);
            SignUpPage signUpPage = PageFactory.initElements(driver, SignUpPage.class);
            DropdownsPage dropdownsPage = PageFactory.initElements(driver, DropdownsPage.class);

            //Method that performs click action
            //webElements.ClickAction();
            //dropdownsPage.clickAction();

            //Method to verify /sign up page URL
            signUpPage.verifySignUpPage();

            //Go back to Dropdowns page via browser
            driver.navigate().back();

            //Method to verify /dropdowns page URL
            dropdownsPage.verifyDropdownsPage();

            System.out.println("Test Case 1: passed");

        }


        //@AfterClass
        //public static void quit() {

        //}

        //public static void tearDown ()
        //{
            //BrowserFactory.closeBrowser();
        //}
        @AfterClass
        public static void closeBrowser() {
            After.closeBrowser();

        }

    }






