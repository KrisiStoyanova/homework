package Homework10PageFactory.Helpers;

public class After extends BrowserFactory {
    public void quit () {
        closeBrowser();
    }
}


