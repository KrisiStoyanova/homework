package Helpers;

import PageObjectModels.DropdownsPage;
import PageObjectModels.SignUpPage;
import PageObjectModels.TestPage;
import PageObjectModels.WebElements;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static Helpers.BrowserFactory.getBrowser;

public class Before extends BrowserFactory {

    public static void setup() {
        //Create a Chrome driver. All test classes use this.
        WebDriver driver = BrowserFactory.getBrowser("Chrome");
        driver.get("https://letcode.in/dropdowns");
        driver.manage().window().maximize();
        //WebElements webElements = PageFactory.initElements(driver, WebElements.class);
        //DropdownsPage dropdownsPage = PageFactory.initElements(driver, DropdownsPage.class);
    }
}




