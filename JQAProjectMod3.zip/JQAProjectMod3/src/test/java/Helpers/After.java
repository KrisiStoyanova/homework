package Helpers;

import static Homework9.Homework9.closeBrowser;

public class After extends BrowserFactory {

    public void quit() {
        closeBrowser();
    }
}



